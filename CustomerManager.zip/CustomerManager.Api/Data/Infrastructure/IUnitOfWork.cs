﻿using CustomerManager.Api.Data.Customers.Interfaces;

namespace CustomerManager.Api.Data.Infrastructure
{
    public interface IUnitOfWork
    {
        ICustomerRepository CustomerRepository { get; }
        IRepository<T> Repository<T>() where T : class;
        Task<int> SaveChangesAsync(CancellationToken cancellation);
    }
}
