﻿using CustomerManager.Api.Data.Infrastructure;
using CustomerManager.Models.Models;

namespace CustomerManager.Api.Data.Customers.Interfaces
{
    public interface ICustomerRepository : IRepository<Customer>
    {
        Task<Customer?> GetByNameAsync(string nameme);
        Task<Customer?> GetByEmailAsync(string email);
    }
}
